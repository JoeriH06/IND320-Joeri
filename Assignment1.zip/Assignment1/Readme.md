# This is gonna be the readme
https://joeri-assignment-1.streamlit.app/
